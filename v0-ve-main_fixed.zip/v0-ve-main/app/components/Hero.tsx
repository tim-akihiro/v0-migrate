<motion.h1 className="mt-10 text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-brand-700 to-brand-500">
  <span>Flowers & Saints</span>
</motion.h1>

<a
  className="px-6 py-3 rounded-full bg-brand-500 text-white font-semibold transition-all duration-300 ease-in-out hover:bg-brand-500/90 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-opacity-50"
  …
>
  Explore Our Work
</a>
